declare module 'canvas-confetti';
